<html>
<head>
    <title>Home Page</title>
    <link rel="stylesheet" href="../styles/homePage_style.css"/>
</head>
<body>
<?php
require "header.php";
?>
<div class="content">
  <h1>Welcome to Gaming Buddy</h1>
</div>
<?php
include "footer.php";
?>
</body>
</html>
