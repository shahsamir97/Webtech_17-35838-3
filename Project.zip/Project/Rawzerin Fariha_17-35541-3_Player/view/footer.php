<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../styles/footer_style.css">
</head>
<body>
<div class="footer">
    <h5>Copyright © 2021</h5>
    <h4> Contact : gamingbuddy@gmail.com</h4>
</div>

</body>
</html>
