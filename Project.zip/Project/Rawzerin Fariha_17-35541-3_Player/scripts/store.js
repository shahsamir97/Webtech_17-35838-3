
function goToProductDetails(productId) {
    window.location.href = "../view/product_detail_view.php?productId="+productId
}