<?php
$hostName='localhost';
$userName='root';
$password='';
$dbName='game';
$db= mysqli_connect($hostName,$userName,$password,$dbName);
?>