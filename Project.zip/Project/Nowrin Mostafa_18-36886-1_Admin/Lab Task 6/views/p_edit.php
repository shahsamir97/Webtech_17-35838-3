
<html>
  <head>
    <?php include 'user_header_head.php';  $id=$_GET["gid"];?>
  </head>
  <body>
    <?php
    include 'user_header_body.php';
    include_once 'db.php';

    $prname=$_POST['prname'];
    $des=$_POST['desc'];
    $dlink=$_POST['dlink'];
    $glink=$_POST['glink'];
    $con=$_POST['con'];
    $gtype=$_POST['gtype'];
    $verf="no";


    $sql= "INSERT INTO game (title, dlink, glink, con, gtype, uid, verf) VALUES ('$prname','$des','$glink','$con','$gtype','$uid', '$verf');";
    $sql="UPDATE game SET title='$prname',des='$des',glink='$glink',con='$con',aid_type='$gtype',`uid`='$uid',`verf`='$verf' WHERE gid=$id;";
    mysqli_query($conn,$sql);
    echo '<span style="color:green; font-size:24px;"><b>Project Updated</b><span>';

    ?>
  </body>
</html>
