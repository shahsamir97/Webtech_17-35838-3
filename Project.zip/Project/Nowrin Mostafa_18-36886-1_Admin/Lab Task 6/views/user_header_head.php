<style>
  body
  {
    background: #ECF0F1 ;
  }
  nav{
    width:100%;
    height:100px;
    background-color:#0038a7;
    border-radius: 15px;
  }
  ul{
    margin:0;
    padding:0;
  }
  ul li {
    list-style:none;
    display:inline-block;
    float:center;

  }
  ul li a {
    display:block;
    text-decoration:none;
    font-size:18px;
    font-family:consolas;
    color:white;
    padding: 10px;
    transition: .5s;
  }
  ul li a:hover {
    color:#1a5276;
    background:  #aed6f1;
    border-radius: 20px;
    height: 25px;

  }
  .logo{
    margin: 0;
    margin-top: 10px;
    padding-right:20%;

  }
  .logo1
  {
    font-family:consolas;
    font-size:35px;
  }
  .logo1:hover
  {
    color:white;
    background: #0038a7;
  }
  .nav1
  {
    text-align: left;
  }
</style>
