<style>
  nav{
    width:100%;
    height:100px;
    background-color:#0B5345;
    border-radius: 15px;
  }
  ul{
    margin:0;
    padding:0;
  }
  ul li {
    list-style:none;
    display:inline-block;
    float:center;

  }
  ul li a {
    display:block;
    text-decoration:none;
    font-size:18px;
    font-family:consolas;
    color:white;
    padding: 10px;
    transition: .5s;
  }
  ul li a:hover {
    color:#0B5345;
    background:  #82E0AA ;
    border-radius: 20px;
    height: 25px;
    
  }
  .logo{
    margin: 0;
    padding-right:370px;
    font-family:consolas;
    font-size:35pt;
  }
  .logo:hover
  {
    color:white;
    background:#0B5345;
  }
  .nav1
  {
    text-align: left;
  }
</style>
