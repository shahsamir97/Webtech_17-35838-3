<!DOCTYPE html>
<html>
<head>
	<?php
	include_once 'db.php';
	include 'jspheader.php';?>
