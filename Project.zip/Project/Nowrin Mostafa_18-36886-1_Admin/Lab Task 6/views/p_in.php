

<html>
  <head>
    <?php include 'user_header_head.php'; ?>
  </head>
  <body>
    <?php
    include 'user_header_body.php';
    include_once 'db.php';

    $prname=$_POST['prname'];
    $des=$_POST['desc'];
    $glink=$_POST['glink'];
    $con=$_POST['con'];
    $gtype=$_POST['gtype'];
    $verf="no";

    $sql= "INSERT INTO projects1 (title, des, glink, con, gtype, uid, verf) VALUES ('$prname','$des','$glink','$con','$gtype','$uid', '$verf');";
    mysqli_query($conn,$sql);

    echo "Game Inserted";

    ?>
  </body>
</html>
