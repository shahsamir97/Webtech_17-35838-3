<?php
    header ("Location:views/index.html");
?>