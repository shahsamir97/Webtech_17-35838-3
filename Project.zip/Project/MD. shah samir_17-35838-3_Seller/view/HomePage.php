<html>
<head>
    <title>Home Page</title>
    <link rel="stylesheet" href="../styles/seller_homePage_style.css">
</head>
<body>
<?php
require "header.php";
?>
<div class="content">
    <h1 class="head-line">Welcome to Gaming Buddy Seller Community</h1>
</div>
<?php
include "footer.php";
?>
</body>
</html>
