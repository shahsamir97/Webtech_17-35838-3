<!DOCTYPE html>
<html>
<head>
    <link type="text/css" rel="stylesheet" href="../styles/footer_style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="footer">
    <h5>Copyright © 2021</h5>
    <h4> Contact : gamingbuddy@gmail.com</h4>
</div>

</body>
</html>
