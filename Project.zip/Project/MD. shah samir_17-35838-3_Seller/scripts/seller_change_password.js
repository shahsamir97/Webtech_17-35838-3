document.getElementById('backButton').addEventListener('click', navigateToProfile)

function navigateToProfile(){
    window.location.href = "../view/seller_profile.php";
}