let profileEditButton = document.getElementById('edit_profile').addEventListener('click',applyProfileEdits)

function applyProfileEdits(){
    window.location.href = "../view/seller_profile_edit.php";
}